//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by matching.rc
//
#define IDD_MATCHMIN_DIALOG             102
#define IDR_MAINFRAME                   128
#define IDC_REGBUTTON                   1000
#define IDC_MATBUTTON                   1001
#define IDC_INITBUTTON                  1002
#define IDC_CONFBUTTON                  1003
#define IDC_REGIMAGE                    1004
#define IDC_MATIMAGE                    1005
#define IDC_EDIT1                       1006
#define IDC_REGIMAGE2                   1006
#define IDC_EDIT2                       1007
#define IDC_EDIT_USER                   1007
#define IDC_COMBO1                      1008
#define IDC_IDENTIFY                    1009
#define IDC_EDIT3                       1010
#define Device                          1011
#define IDC_COMBO_DEVICE                1012
#define IDC_COMBO_FORMAT                1013
#define IDC_PROGRESS2                   1014
#define IDC_BTN_CAPTURE_R1              1014
#define IDC_BTN_CAPTURE_R2              1015
#define IDC_BTN_CAPTURE_V1              1016
#define IDC_BTN_CHANGE_FORMAT           1017

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1018
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
