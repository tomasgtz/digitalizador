//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by sgdvc.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_SGDVC_DIALOG                102
#define IDR_MAINFRAME                   128
#define IDR_MENU1                       129
#define IDD_DEVICE_SELECT               130
#define IDI_ICON1                       133
#define IDD_DIALOG_AUTOON               136
#define IDR_VERSION2                    137
#define IDR_VERSION3                    138
#define IDC_INITBTN                     1000
#define IDC_LEDONOFF                    1001
#define IDC_CONFIG                      1002
#define IDC_CAPTURE                     1003
#define IDC_LIVECAPTURE                 1004
#define IDC_STATIC_DRAW                 1005
#define IDC_STATIC_STATUS               1006
#define IDC_EDIT_SN                     1013
#define IDC_EDIT_IMG_WIDTH              1014
#define IDC_EDIT_ID                     1015
#define IDC_EDIT_IMG_HEIGHT             1016
#define IDC_EDIT_BRIGHTNESS             1017
#define IDC_EDIT_Contrast               1018
#define IDC_EDIT_IMG_QUALITY            1019
#define IDC_EDIT_TIMEOUT                1020
#define IDC_LIST_DEVICE                 1020
#define IDC_EDIT_Gain                   1021
#define IDC_EDIT_FWVersion              1022
#define IDC_EDIT_ImageDPI               1023
#define IDC_CONT_CAPTURE                1029
#define IDC_ENUMBTN                     1035
#define IDC_AUTOONBTN                   1036
#define IDC_ENUMLIST2                   1038
#define IDC_ENUM_DEVID                  1040
#define IDC_AUTOON_CONFIGBTN            1045
#define IDC_IMGFRAME                    1047
#define IDC_BTN_AUTOONEVENT             1048
#define IDC_BTN_TEST                    1050
#define IDC_CHECK1                      1051
#define IDC_CHECK_FINGER_LIVENESS       1051
#define IDC_COMBO_PORTS                 1052
#define IDC_BUTTON_SDA_INIT             1053
#define ID_MENU_EXIT                    32771
#define ID_MENU_ABOUT                   32772
#define ID_MENU_SAVE_BMP                32773
#define ID_MENU_SAVE_RAW                32774
#define ID_MENUITEM32777                32777

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        139
#define _APS_NEXT_COMMAND_VALUE         32778
#define _APS_NEXT_CONTROL_VALUE         1054
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
